import React from 'react';
import { About } from './components/About';
import { Education } from './components/Education';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <header className="min-h-screen flex items-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-black z-0" />
        <div className="container mx-auto px-4 z-10">
          <div className="max-w-4xl">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 transform hover:scale-105 transition-transform">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
                Prashant Shukla
              </span>
            </h1>
            <h2 className="text-2xl md:text-4xl mb-8 text-gray-300">
              Full Stack Developer
            </h2>
            <p className="text-xl text-gray-400 mb-8">
              Crafting digital experiences with code. Specialized in building scalable web applications
              with modern technologies.
            </p>
            <div className="flex gap-4">
              <a href="#contact" className="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-lg font-medium transform hover:scale-105 transition-all">
                Get in Touch
              </a>
              <a href="#projects" className="border border-purple-600 px-6 py-3 rounded-lg font-medium hover:bg-purple-600/20 transform hover:scale-105 transition-all">
                View Projects
              </a>
            </div>
          </div>
        </div>
      </header>

      <About />
      <Education />
      <Experience />
      <Projects />
      <Footer />
    </div>
  );
}

export default App;