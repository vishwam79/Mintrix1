import React from 'react';
import { GraduationCap, Award, Book } from 'lucide-react';

const educationData = [
  {
    year: "2018",
    degree: "Master of Technology in Computer Science",
    institution: "Indian Institute of Technology",
    details: "Specialized in Machine Learning and Data Structures",
    icon: GraduationCap
  },
  {
    year: "2016",
    degree: "Bachelor of Technology in Computer Science",
    institution: "National Institute of Technology",
    details: "First Class with Distinction",
    icon: Award
  },
  {
    year: "2012",
    degree: "Higher Secondary Education",
    institution: "Delhi Public School",
    details: "Science and Mathematics",
    icon: Book
  }
];

export function Education() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Education</h2>
        <div className="max-w-3xl mx-auto">
          {educationData.map((item, index) => (
            <div
              key={index}
              className="relative pl-8 pb-12 group"
              data-aos="fade-up"
              data-aos-delay={index * 100}
            >
              {/* Timeline line */}
              {index !== educationData.length - 1 && (
                <div className="absolute left-4 top-4 bottom-0 w-0.5 bg-purple-600/50" />
              )}
              
              {/* Timeline dot */}
              <div className="absolute left-0 top-2 w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <item.icon className="w-4 h-4 text-white" />
              </div>
              
              {/* Content */}
              <div className="ml-8">
                <span className="text-purple-400 font-semibold">{item.year}</span>
                <h3 className="text-xl font-bold mt-1 mb-2">{item.degree}</h3>
                <p className="text-gray-400 mb-1">{item.institution}</p>
                <p className="text-gray-500">{item.details}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}