import React from 'react';

export function About() {
  return (
    <section className="py-20 bg-black/90">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">About Me</h2>
        <div className="max-w-3xl mx-auto bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 rounded-lg p-8 transform hover:scale-105 transition-all">
          <p className="text-gray-300 leading-relaxed mb-4">
            Hello! I'm Prashant Shukla, a passionate Full Stack Developer based in India with over 5 years of experience in crafting digital solutions. My journey in technology began with a fascination for creating user-centric applications, and it has evolved into a deep expertise in both frontend and backend development.
          </p>
          <p className="text-gray-300 leading-relaxed mb-4">
            I specialize in building scalable web applications using modern technologies like React, Node.js, and Cloud Services. My approach combines technical excellence with creative problem-solving, ensuring that each project not only meets but exceeds client expectations.
          </p>
          <p className="text-gray-300 leading-relaxed">
            When I'm not coding, I'm actively contributing to open-source projects, mentoring aspiring developers, and staying updated with the latest technology trends. I believe in writing clean, maintainable code and creating solutions that make a real difference in users' lives.
          </p>
        </div>
      </div>
    </section>
  );
}