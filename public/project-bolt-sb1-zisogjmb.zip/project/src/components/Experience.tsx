import React from 'react';
import { Briefcase, Code, Server } from 'lucide-react';

const experiences = [
  {
    company: "Tech Innovators Ltd",
    role: "Senior Full Stack Developer",
    period: "2021 - Present",
    description: "Leading development of enterprise-scale applications using React and Node.js",
    achievements: [
      "Improved application performance by 40%",
      "Led a team of 5 developers",
      "Implemented microservices architecture"
    ],
    icon: Code
  },
  {
    company: "Digital Solutions Inc",
    role: "Full Stack Developer",
    period: "2019 - 2021",
    description: "Developed and maintained multiple client projects",
    achievements: [
      "Built scalable e-commerce platforms",
      "Integrated payment gateways",
      "Reduced loading time by 50%"
    ],
    icon: Server
  },
  {
    company: "StartUp Hub",
    role: "Junior Developer",
    period: "2018 - 2019",
    description: "Worked on innovative startup projects",
    achievements: [
      "Developed MVP for 3 startups",
      "Implemented real-time features",
      "Optimized database queries"
    ],
    icon: Briefcase
  }
];

export function Experience() {
  return (
    <section className="py-20 bg-black/90">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Experience</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 rounded-lg p-6 transform hover:scale-105 transition-all"
            >
              <div className="text-purple-400 mb-4">
                <exp.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">{exp.role}</h3>
              <h4 className="text-purple-400 mb-2">{exp.company}</h4>
              <p className="text-gray-400 text-sm mb-2">{exp.period}</p>
              <p className="text-gray-300 mb-4">{exp.description}</p>
              <ul className="text-gray-400 text-sm space-y-1">
                {exp.achievements.map((achievement, i) => (
                  <li key={i} className="flex items-center">
                    <span className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2" />
                    {achievement}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}