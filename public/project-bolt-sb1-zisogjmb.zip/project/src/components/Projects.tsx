import React from 'react';
import { ExternalLink } from 'lucide-react';

const projects = [
  {
    title: "E-Commerce Platform",
    description: "A full-featured e-commerce platform with real-time inventory management and payment processing",
    image: "https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&q=80&w=1000",
    technologies: ["React", "Node.js", "MongoDB", "Stripe"],
    liveUrl: "https://example.com",
    featured: true
  },
  {
    title: "AI Chat Application",
    description: "Real-time chat application with AI-powered responses and language translation",
    image: "https://images.unsplash.com/photo-1587560699334-cc4ff634909a?auto=format&fit=crop&q=80&w=1000",
    technologies: ["Next.js", "Python", "TensorFlow", "WebSocket"],
    liveUrl: "https://example.com"
  },
  {
    title: "Task Management System",
    description: "Enterprise task management system with real-time updates and team collaboration",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=1000",
    technologies: ["Vue.js", "Express", "PostgreSQL", "Redis"],
    liveUrl: "https://example.com"
  },
  {
    title: "Healthcare Portal",
    description: "Secure healthcare management system for patient records and appointments",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=1000",
    technologies: ["React", "Node.js", "MySQL", "Docker"],
    liveUrl: "https://example.com"
  },
  {
    title: "Social Media Analytics",
    description: "Analytics dashboard for social media metrics and engagement tracking",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1000",
    technologies: ["Angular", "Python", "Django", "D3.js"],
    liveUrl: "https://example.com"
  },
  {
    title: "Real Estate Platform",
    description: "Property listing and management platform with virtual tours",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=1000",
    technologies: ["Next.js", "Node.js", "PostgreSQL", "Three.js"],
    liveUrl: "https://example.com"
  }
];

export function Projects() {
  return (
    <section className="py-20 bg-black" id="projects">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Featured Projects</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-lg bg-gradient-to-br from-purple-900/30 to-black border border-purple-900/50 transform hover:scale-105 transition-all"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-400 mb-4 text-sm">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, i) => (
                    <span
                      key={i}
                      className="text-xs px-2 py-1 rounded-full bg-purple-900/50 text-purple-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
                >
                  View Website <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}